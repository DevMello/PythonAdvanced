import mysql.connector

mydb = mysql.connector.connect(
    host="192.168.163.196", # change this to your wsl ip address
    user="devmello",
    password="password",
)

mycursor = mydb.cursor()

# Create the database
# mycursor.execute("CREATE DATABASE `Test Database`")

# Connect to the newly created database
mydb = mysql.connector.connect(
    host="192.168.163.196",
    user="devmello",
    password="password",
    database="Test Database"
)

# Create a cursor object to execute SQL queries within the new database
mycursor = mydb.cursor()

# Create a schema for the database


# Commit changes and close connection
mydb.commit()
mydb.close()

print("Database 'Test Database' and schema created successfully!")