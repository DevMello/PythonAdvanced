import mysql.connector

mydb = mysql.connector.connect(
    host="192.168.163.196", # change this to your wsl ip address
    user="devmello",
    password="password",
)

mycursor = mydb.cursor()

# Create the database
# mycursor.execute("CREATE DATABASE `Test Database`")

# Connect to the newly created database
mydb = mysql.connector.connect(
    host="192.168.163.196",
    user="devmello",
    password="password",
    database="Test Database"
)

# Create a cursor object to execute SQL queries within the new database
mycursor = mydb.cursor()

# Create Users Table
mycursor.execute("CREATE TABLE Users (Id INT AUTO_INCREMENT PRIMARY KEY, Email VARCHAR(255), Password VARCHAR(255), "
                 "Address VARCHAR(255))")

# Create Products Table
mycursor.execute("CREATE TABLE Products (ID INT AUTO_INCREMENT PRIMARY KEY, Name VARCHAR(255), Description TEXT, "
                 "Price DECIMAL(10, 2), Category VARCHAR(255), Image VARCHAR(255), User_id INT, FOREIGN KEY (User_id) "
                 "REFERENCES Users(Id))")

# Create Cart Table
mycursor.execute("CREATE TABLE Cart (Id INT AUTO_INCREMENT PRIMARY KEY, UserID INT, Products_id INT, FOREIGN KEY ("
                 "UserID) REFERENCES Users(Id), FOREIGN KEY (Products_id) REFERENCES Products(ID))")

# Create Transactions Table
mycursor.execute("CREATE TABLE Transactions (ID INT AUTO_INCREMENT PRIMARY KEY, User_id INT, Address VARCHAR(255), "
                 "Total DECIMAL(10, 2), Receipt_ID VARCHAR(8), FOREIGN KEY (User_id) REFERENCES Users(Id))")

# Commit changes and close connection
mydb.commit()
mydb.close()

print("Database 'Test Database' and schema created successfully!")